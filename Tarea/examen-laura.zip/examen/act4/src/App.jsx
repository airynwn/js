import './App.css'
import Micomponente from './micomponente/Micomponente'
import Segundoconversor from './segundoconversor/Segundoconversor'

function App() {
  return (
    <div>
      <Micomponente />
      <Segundoconversor />
    </div>
  )
}

export default App
